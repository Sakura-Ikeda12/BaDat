Drop database if exists Proveedores;
create database Proveedores;
use Proveedores;

create table Clientes (
id_cliente int auto_increment PRIMARY key,
nombre varchar(25) not null,
apellido1 varchar(25) not null,
apellido2 varchar(25), 
tlf varchar(9) not null UNIQUE);


create table vendedores (
id_vendedor int primary key,
nombre varchar(25) not null,
apellido1 varchar(25) not null,
apellido2 varchar(25),
tlf varchar(9) not null UNIQUE);



create table Productos (
id_producto int auto_increment primary KEY,
nombre_producto varchar(50),
fabricante varchar(30) not null, 
tlf_servicio int(9) not null,
email_servicio VARCHAR(50),
web varchar(50));

create table ventas(
id_venta int auto_increment primary key,
id_producto int(3),
id_cliente int(3),
id_vendedor int(3),
constraint  p_FK FOREIGN KEY (id_producto) REFERENCES productos (id_producto) on delete CASCADE on update CASCADE,
constraint  c_FK FOREIGN KEY (id_cliente) REFERENCES clientes (id_cliente) on delete CASCADE on update CASCADE,
constraint  v_FK FOREIGN KEY (id_vendedor) REFERENCES vendedores (id_vendedor) on delete CASCADE ON update CASCADE);

create table pedidos (
id_pedido int auto_increment primary key,
id_producto int(3),
id_cliente int(3) ,
id_vendedor int(3),
cantidad int(2) not null DEFAULT 0,
precio float(5,2) not null,
fecha datetime not NULL, 
constraint  productos_FK FOREIGN KEY (id_producto) REFERENCES productos (id_producto) on delete CASCADE on update CASCADE,
constraint  clientes_FK FOREIGN KEY (id_cliente) REFERENCES clientes (id_cliente) on delete CASCADE on update CASCADE,
constraint  vendedores_FK FOREIGN KEY (id_vendedor) REFERENCES vendedores (id_vendedor) on delete CASCADE on update CASCADE);

LOAD DATA INFILE '/Users/saku/Desktop/1DAM/base de datos/sql/archivos .csv/clientes.csv'
INTO TABLE clientes
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA INFILE 'C:/Users/saku/Desktop/1DAM/base de datos/sql/archivos .csv/vendedores.csv'
INTO TABLE vendedores
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;



INSERT INTO vendedores (id_vendedor,nombre, apellido1, apellido2, tlf)
VALUES 
  ('6','Javier', 'García', 'Fernández', '637123456'),
  ('7','Ana', 'López', 'Pérez', '662345678'),
  ('8','Marcos', 'Moreno', 'Gómez', '611284567'),
  ('9','Martina', 'Ruiz', 'Martínez', '655789812'),
  ('10','Pablo', 'Rodríguez', 'Sánchez', '688906234');
  
  INSERT INTO productos (nombre_producto, fabricante, tlf_servicio, email_servicio, web) VALUES
('Zapatillas deportivas', 'Nike', '600112233', 'info@nike.com', 'https://www.nike.com'),
('Cafetera de cápsulas', 'Bosch', '667788990', 'ayuda_tecnica@bosch.com', 'https://www.bosch-home.com'),
('Smartwatch', 'Samsung', '912345678', 'soporte@Samsung.com', 'https://www.samsung.com'),
('Cámara de fotos reflex', 'Sony', '696969696', 'soporte_tecnico@sony.com', 'https://www.sony.com'),
('Videojuego para consola', 'Sony', '686969696', 'soporte_tecnico@playstation.com', 'https://www.playstation.com'),
('Televisor 4K', 'LG', '931234567', 'servicio_tecnico@lg.com', 'https://www.lg.com'),
('Altavoz Bluetooth', 'Bose', '952222222', 'atencion_al_cliente@bose.com', 'https://www.bose.com'),
('Robot aspirador', 'Xiaomi', '654321098', 'soporte@mi.com', 'https://www.mi.com'),
('Plancha de pelo', 'Philips', '666555444', 'consultas@philips.com', 'https://www.philips.com'),
('Juego de sábanas', 'Ikea', '971111111', 'atencion_cliente@ikea.com', 'https://www.ikea.com');

INSERT INTO ventas (id_venta, id_producto, id_cliente, id_vendedor)
VALUES (1, 1, 1, 1),
       (2, 2, 2, 2),
       (3, 3, 3, 3),
       (4, 4, 4, 4),
       (5, 5, 5, 5);

INSERT INTO pedidos (id_producto, id_cliente, id_vendedor, cantidad, precio, fecha)
SELECT id_producto, id_cliente, id_vendedor, 0, 0.0, '2023-04-02' FROM ventas;


update pedidos set id_pedido = 7 where id_pedido = 3; 
update pedidos set id_producto = 9 where id_producto = 2; 
update pedidos set id_vendedor = 4 where id_vendedor = 5; 
update pedidos set id_cliente = 2 where id_cliente = 1; 
update clientes set id_cliente = 78 where id_cliente = 4; 
update vendedores set id_vendedor = 65 where id_vendedor = 1; 
update productos set id_producto = 765 where id_producto = 5; 

Delete from clientes where id_cliente = 2;
delete from productos where id_producto = 4;
delete from vendedores where id_vendedor = 3;


